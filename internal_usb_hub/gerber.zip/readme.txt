HUB_FPC.GBSTF file in the gerber zip file designates three areas of bottom stiffener. The board outline is also included in the file.
Every stiffener thickness is not the same, so please be careful.
